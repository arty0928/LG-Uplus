package com.uplus.eureka.member.model.dto;

public class MemberException extends RuntimeException {
	public MemberException(String msg) {
		super(msg);
	}
}
