package com.uplus.eureka.memo.model.dto;

import com.uplus.eureka.EurekaException;

public class MemoException extends EurekaException {
	public MemoException(String msg) {
		super(msg);
	}
}
