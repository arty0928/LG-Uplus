package com.uplus.eureka.memo.model.dto;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name="memo")
@Data
public class Memo implements Serializable {
	private static final long serialVersionUID=1L;
	@Schema(hidden = true)
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Schema(description = "user id" 	, example = "eureka")
	@Column(length = 30)
	private String userId;
	
	@Schema(description = "내용" 	, example = "유레카")
	@Column(length = 2000)
	private String content;
}
