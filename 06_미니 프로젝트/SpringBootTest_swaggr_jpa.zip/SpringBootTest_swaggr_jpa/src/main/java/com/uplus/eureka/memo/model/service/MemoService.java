package com.uplus.eureka.memo.model.service;

import java.util.List;

import com.uplus.eureka.memo.model.dto.Memo;

public interface MemoService {
	Memo search(Integer id) ;
	List<Memo> searchUserId(String userId) ;
	void regist(Memo user) ;
	void update(Memo user) ;
	void remove(Integer  id)   ;
}
