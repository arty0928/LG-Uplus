package com.uplus.eureka.memo.controller;

import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uplus.eureka.EurekaException;
import com.uplus.eureka.memo.model.dto.Memo;
import com.uplus.eureka.memo.model.service.MemoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController	
@RequestMapping("/memo")
@Tag(name = "메모 Rest 컨트롤러", description = "간단히 메모한 내용에 대한 목록과 상세보기, 등록, 수정, 삭제등 전반적인 메모 정보 관리를 처리하는 클래스")
@AllArgsConstructor
@Slf4j
public class MemoRestController {
	private static final String SUCCESS="SUCCESS";
	
	private MemoService memoService;

	@ExceptionHandler
	public ResponseEntity<String> handler(Exception e){
		log.error("msg:{}", e.getMessage());
		
		HttpHeaders resheader = new HttpHeaders();
		//에러메세지가 한글인 경우 깨지므로 한글 처리를 위한 응답 헤더 설정
		resheader.add("Content-Type","application/json;charset-UTF-8");
		
		String msg ="처리 중 오류 발생";
		if (e instanceof EurekaException) {
			msg = e.getMessage();
		}		
		return new ResponseEntity<String>(msg, resheader, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@Operation(	summary = "메모 상세 정보", 
			description = "메모 아이디에 대한 메모의 상세 정보를 반환해 줍니다. ",
			responses ={
					@ApiResponse(responseCode = "200", description = "메모 상세 정보 OK!!"),
			}
		  )
	@GetMapping("/{id}")
	public ResponseEntity<Memo> search(@PathVariable("id") Integer id){
		log.debug("id:{}", id);
		Memo book = memoService.search(id);
		return new ResponseEntity<>(book, HttpStatus.OK);
	}
	
	@Operation(	summary = "메모 목록", 
				description = "사용자가 작성한 모든 메모를 반환해 줍니다.",
				responses ={
						@ApiResponse(responseCode = "200", description = "책목록 OK!!"),
				}
			  )
	@GetMapping
	public ResponseEntity<?> searchAll(String userId){
		log.debug("userId:{}", userId);
		List<Memo> memos = memoService.searchUserId(userId);
		log.debug("memos:{}", memos);
		
		if(memos!=null && memos.size()>0) {
			return new ResponseEntity<List<Memo>>(memos, HttpStatus.OK);
		}else {
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		}
	}
	
	@Operation(	summary = "책 정보 등록", 
			description = "",
			responses ={
					@ApiResponse(responseCode = "200", description = "책목록 OK!!"),
			}
		  )
	@PostMapping
	public ResponseEntity<String> regist(@RequestBody @Schema(implementation = Memo.class) Memo memo){
		log.debug("regist- memo:{}",memo);
		memoService.regist(memo);
		return new ResponseEntity<String>(SUCCESS, HttpStatus.CREATED);
	}
	
	@Operation(	summary = "수정", 
			description = "id 대한 메모 정보를 수정해 줍니다.",
			responses ={
					@ApiResponse(responseCode = "200", description = "수정 OK!!"),
			}
		  )
	@PutMapping
	public ResponseEntity<String> update(@RequestBody @Schema(implementation = Memo.class) Memo memo){
		log.debug("update- memo:{}",memo);
		memoService.update(memo);
		return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
	}
	
	@Operation(	summary = "id에대한 메모를 삭제", 
			description = "id에 대한 메모를 삭제해 줍니다.",
			responses ={
					@ApiResponse(responseCode = "200", description = "삭제 OK!!"),
			},
			parameters= {
					@Parameter(name="id", description = "", required = true, example="")
			}
	)	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> remove(@PathVariable("id") Integer id){
		log.debug("remove- id:{}",id);
		memoService.remove(id);
		return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
	}
}






