package com.uplus.eureka.memo.model.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.uplus.eureka.memo.model.dto.Memo;
import com.uplus.eureka.memo.model.dto.MemoException;
import com.uplus.eureka.meno.model.dao.MemoDao;


@Service
public class MemoServiceImp implements MemoService {
	
	private MemoDao dao ;
	
	public MemoServiceImp(MemoDao dao) {
		super();
		this.dao = dao;
	}
	
	
	@Override
	@Transactional(readOnly = true)
	public Memo search(Integer id) {
		Memo memo = dao.findById(id).orElseThrow(()->new MemoException("등록되지 않은 아이디입니다."));
		return memo;
	}
	@Override
	@Transactional(readOnly = true)
	public List<Memo> searchUserId(String id) {
		List<Memo> memos = dao.findByUserId(id);
		return memos;
	}

	@Override
	@Transactional
	public void regist(Memo memo) {
		System.out.println("여기~~");
		memo.setId(null);
	    dao.save(memo);
	}

	@Override
	@Transactional
	public void update(Memo memo) {
			dao.findById(memo.getId()).orElseThrow(()->new MemoException("등록되지 않은 아이디입니다."));
			dao.save(memo);
	}

	@Override
	@Transactional
	public void remove(Integer id) {
		Memo memo = dao.findById(id)
			    .orElseThrow(() -> new MemoException("등록되지 않은 아이디입니다."));
		dao.delete(memo);
	}
}




