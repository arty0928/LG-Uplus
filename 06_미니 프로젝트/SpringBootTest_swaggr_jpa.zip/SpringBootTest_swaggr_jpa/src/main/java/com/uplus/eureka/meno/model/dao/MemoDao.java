package com.uplus.eureka.meno.model.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.uplus.eureka.memo.model.dto.Memo;



public interface MemoDao extends JpaRepository<Memo, Integer>{
	List<Memo> findByUserId(String userId);
}
