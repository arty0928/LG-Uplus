package com.uplus.eureka.book.model.dto;

public class BookException extends RuntimeException {
	public BookException(String msg) {
		super(msg);
	}
}
